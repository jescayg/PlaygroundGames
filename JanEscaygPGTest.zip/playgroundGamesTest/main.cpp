/**
 * Author: Jan-Christian Escayg
 * Application: Run length encoding for Playground Games - Student placement 2020
 */

#include <iostream>
#include <streambuf>
#include <fstream>
#include <vector>
using namespace std;

/**
 * A method to compress a string through run length encoding
 *
 * @param basicString - string passed through to be compressed
 * @return answer = compressed basic string
 */
string compress(string basicString)
{
    string answer = "";
    int stringLength = basicString.length();
    for (int i = 0; i < stringLength; i++)
    {
        int count = 1;
        while (i < stringLength - 1 && basicString[i] == basicString[i + 1])
        {
            count++;
            i++;
        }
        answer.append(to_string(count));
        answer.push_back(basicString[i]);
    }
    return answer;
}

/**
 * A method to decompress a string through run length encoding
 *
 * @param basicString - string passed through to be decompressed
 * @return answer = decompressed basic string
 */
string decompress(string basicString)
{
    string answer = "";
    char character;
    int num;
    vector<int> vector;
    int stringLength = basicString.length();
    for (int i = 0; i < stringLength; i++)
    {
        character = basicString[i];
        num = (int) character;
        // If the value is a number it will assign it to a vector
        if (47 < num && num < 58)
        {
            num = character - 48; // Shifts the ASCII value to decimal val
            vector.push_back(num);
        }
        else {
            int vectorToNum = 0;
            for (auto d : vector)
            {
                vectorToNum = vectorToNum * 10 + d;
            }
            for (int j = 0; j < vectorToNum; j++)
            {
                answer.push_back(character);
            }
            vector.clear();
        }
    }
    return answer;
}


/**
 * A method to test both my compression and decompression functions and
 * output "success" or "failed" based on the result
 */
void testRLE()
{
    string string1 = "hhhhhhhhhhhhhhhhhhhhheellooWooorld";
    cout << "test string: " + string1+ "\n";
    string compressed = compress(string1);
    cout << "Compressed: " + compressed + "\n";
    string decompressed = decompress(compressed);
    cout << "Decompressed: " + decompressed+ "\n";
    if (string1 == decompressed)
    {
        cout << "Success";
    }
    else
    {
        cout << "Failed";
    }
}


/**
 * A method to read from a file and store the data into a vector array
 *
 * @param path - filename
 * @return vector of string (data read)
 */
string readFromFile(string path)
{
    // Currently incomplete
    ifstream t(path);
    string answer((istreambuf_iterator<char>(t)),(istreambuf_iterator<char>()));
    return answer;
}

/**
 * A method calling my read from file method to test that it works correctly
 */
void testRFF()
{
    string path = "compress_decompress_2.txt";
    cout << readFromFile(path);
}


/**
 * A method to output the string passed through to a text file.
 *
 * @param basicString - string to be saved to txt file
 */
void outputToFile(string basicString)
{

    ofstream file;
    file.open("ouput.txt", ios_base::app);
    file << basicString + "\n";
    cout << "Successfully printed to a file \n";
    if (file.is_open()){}
    else cout << "Unable to open file";
}

/**
 * A method calling my output to a file method to test that it works correctly
 */
void testOTF()
{
    outputToFile("Hello World");
}

int main()
{
    //testRLE();
    //testOTF();
    //testRFF();


    // Load the paths to the files
    string file1 = "compress_decompress_1.txt";
    string file2 = "compress_decompress_2.txt";

    // Read in the data
    string data1 = readFromFile(file1);
    string data2 = readFromFile(file2);

    // Compress both sets of data
    string compressAns1 = compress(data1);
    string compressAns2 = compress(data2);

    // Decompress both sets of data
    string decompAns1 = decompress(data1);
    string decompAns2 = decompress(data2);

    // Output both sets of results to a file

    outputToFile(file1);
    outputToFile("Compressed answer1:");
    outputToFile(compressAns1);
    outputToFile("Decompressed answer1:");
    outputToFile(decompAns1);

    outputToFile(file2);
    outputToFile("Compressed answer2:");
    outputToFile(compressAns2);
    outputToFile("Decompressed answer2:");
    outputToFile(decompAns2);
    return 0;
}