I ran this program through Clion just run the main() function. (As I have the code all set up to run each function)

I began to solving this by logically picking apart the problem and thinking how i would solve it myself - 
then i wrote a basic piece pseudocode for the compression and decompression based on this, and then began coding.

My 1st attempt at coding the compression was to: 
count the number of times the letter is the same as the following and once its not save the number of times
 and then count again for the following letter (each time storing the letter that repeated too).

My 1st attempt at coding the decompression was to:
look at the 1st digit in the string then for that number repeat the letter following that number
after coding this i realised that for larger sets you need to look at all the numbers in front of the letter 

2nd attempt at decompression:
iterate while the next char is an integer and add that integer to an array of numbers 
and then loop for that number of times writing the next char that amount of times. 
To code this i added each integer value to a vector array (as i wasn't sure how else to hold the intergers one by one)
and then once the next value wasn't an integer i converted the vector to an integer and looped for that many times added the char
to an answer string to be returned.

This method proved to be succesful however, I know it wasn't the most efficient of solutions however I am not familiar enough
in C++ to optimise it as of yet. 


For testing the compression & decompression i ran both methods against each other to see if the output of the starting string 
would be the same as a string that was passed through both methods. Which helped me realise my solution to decompression 
didn't work everytime.

Then I had to create methods to read from a text file and to output to a text file. 

Once done with that I made calls to all my functions created in main to get the program running in unison. 




================= 
Output:

compress_decompress_1.txt
Compressed answer1:
4b3s3d1 1b1d1s1 4w4e1 1l1k1 2k1j1s1d1h1f4n1 4h5i1q1w1e1 1w1i1e1i1e4k1r1i1 2k131p1 1s1j2d1j3d1i1o1p1 1i3o2i3e2r6u
Decompressed answer1:
ppp

compress_decompress_2.txt
Compressed answer2:
84121314251612131415161.14651817128165516171614152615531219151219121813141j
Decompressed answer2:


=================

Thank you for taking the time into looking at my application. :)
